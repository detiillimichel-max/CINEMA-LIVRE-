(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ---------- armazenamento local (com proteção) ----------
  const guardar = {
    ler(k, padrao) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : padrao; } catch { return padrao; } },
    gravar(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
  };
  let favoritos = new Set(guardar.ler("cl_favs", []));
  let minhaLista = guardar.ler("cl_minha", []);
  const salvarFavs = () => guardar.gravar("cl_favs", [...favoritos]);
  const salvarMinha = () => guardar.gravar("cl_minha", minhaLista);

  // ---------- fontes de vídeo ----------
  const chave = (v) => `${v.fonte}:${v.id}`;
  const capa = (v) => v.fonte === "youtube"
    ? `https://i.ytimg.com/vi/${encodeURIComponent(v.id)}/hqdefault.jpg`
    : `https://archive.org/services/img/${encodeURIComponent(v.id)}`;
  const embed = (v) => v.fonte === "youtube"
    ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.id)}?autoplay=1&rel=0`
    : `https://archive.org/embed/${encodeURIComponent(v.id)}`;
  const origem = (v) => v.fonte === "youtube"
    ? `https://www.youtube.com/watch?v=${encodeURIComponent(v.id)}`
    : `https://archive.org/details/${encodeURIComponent(v.id)}`;

  function lerLink(texto) {
    let u;
    try { u = new URL(texto.trim()); } catch { return null; }
    const h = u.hostname.replace(/^www\./, "");
    if (h === "youtu.be") return { fonte: "youtube", id: u.pathname.slice(1).split("/")[0] };
    if (h.endsWith("youtube.com") || h.endsWith("youtube-nocookie.com")) {
      const v = u.searchParams.get("v");
      if (v) return { fonte: "youtube", id: v };
      const m = u.pathname.match(/^\/(?:embed|shorts|live)\/([\w-]{11})/);
      if (m) return { fonte: "youtube", id: m[1] };
    }
    if (h === "archive.org") {
      const m = u.pathname.match(/^\/(?:details|embed)\/([^/]+)/);
      if (m) return { fonte: "archive", id: decodeURIComponent(m[1]) };
    }
    return null;
  }

  // ---------- cartões ----------
  function cartao(v, { remover = false } = {}) {
    const el = document.createElement("article");
    el.className = "card";
    const fav = favoritos.has(chave(v));
    el.innerHTML = `
      <span class="selo">${v.fonte === "youtube" ? "YouTube" : "Archive"}</span>
      <button class="${remover ? "apagar" : "estrela" + (fav ? " on" : "")}" aria-label="${remover ? "Remover" : "Favoritar"}">${remover ? "✕" : "★"}</button>
      <div class="capa ${v.fonte === "youtube" ? "yt" : ""}" style="background-image:url('${esc(capa(v))}')"></div>
      <div class="info">
        <div class="nome">${esc(v.titulo || "Sem título")}</div>
        <div class="sub">${[v.ano, v.categoria].filter(Boolean).map(esc).join(" · ")}</div>
      </div>`;
    el.addEventListener("click", (e) => {
      if (e.target.closest("button")) return;
      abrirPlayer(v);
    });
    el.querySelector("button").addEventListener("click", () => {
      if (remover) {
        minhaLista = minhaLista.filter((x) => chave(x) !== chave(v));
        salvarMinha(); renderMinha();
      } else {
        const k = chave(v);
        favoritos.has(k) ? favoritos.delete(k) : favoritos.add(k);
        salvarFavs();
        el.querySelector(".estrela").classList.toggle("on", favoritos.has(k));
      }
    });
    return el;
  }

  function desenhar(alvo, lista, opcoes) {
    alvo.replaceChildren(...lista.map((v) => cartao(v, opcoes)));
  }

  // ---------- player ----------
  let ultimoFoco = null;
  function abrirPlayer(v) {
    ultimoFoco = document.activeElement;
    $("player-titulo").textContent = v.titulo || "";
    $("quadro").src = embed(v);
    $("origem").href = origem(v);
    $("player").hidden = false;
    document.body.style.overflow = "hidden";
    $("fechar").focus();
  }
  function fecharPlayer() {
    $("quadro").src = "about:blank";
    $("player").hidden = true;
    document.body.style.overflow = "";
    if (ultimoFoco && ultimoFoco.focus) ultimoFoco.focus();
  }
  $("fechar").addEventListener("click", fecharPlayer);
  $("player").addEventListener("click", (e) => { if (e.target === $("player")) fecharPlayer(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("player").hidden) fecharPlayer(); });

  // ---------- abas ----------
  document.querySelectorAll("#abas button").forEach((b) => b.addEventListener("click", () => {
    document.querySelectorAll("#abas button").forEach((x) => x.classList.toggle("on", x === b));
    ["catalogo", "archive", "minha"].forEach((n) => { $("aba-" + n).hidden = n !== b.dataset.aba; });
    if (b.dataset.aba === "archive" && !archive.iniciado) buscarArchive(true);
  }));

  // ---------- catálogo (data/videos.json) ----------
  let catalogo = [];
  async function carregarCatalogo() {
    try {
      const r = await fetch("data/videos.json", { cache: "no-cache" });
      catalogo = await r.json();
    } catch { catalogo = []; }
    renderCatalogo();
  }
  function renderCatalogo() {
    const f = $("filtro").value.trim().toLowerCase();
    const lista = catalogo.filter((v) =>
      !f || `${v.titulo} ${v.categoria || ""} ${v.ano || ""}`.toLowerCase().includes(f));
    desenhar($("grade-catalogo"), lista);
    if (!lista.length) {
      $("grade-catalogo").innerHTML = '<p class="msg">Nenhum filme no catálogo. Use a aba "Buscar no Archive" ou edite data/videos.json.</p>';
    }
  }
  $("filtro").addEventListener("input", renderCatalogo);

  // ---------- busca ao vivo no Internet Archive ----------
  const archive = { iniciado: false, pagina: 1, carregando: false };
  const POR_PAGINA = 24;

  async function buscarArchive(nova) {
    if (archive.carregando) return;
    archive.carregando = true;
    archive.iniciado = true;
    if (nova) { archive.pagina = 1; $("grade-archive").replaceChildren(); }

    const termo = $("termo").value.trim().replace(/["\\]/g, " ");
    const partes = [$("colecao").value, "mediatype:movies"];
    if (termo) partes.unshift(`(title:(${termo}) OR subject:(${termo}) OR description:(${termo}))`);

    const p = new URLSearchParams({
      q: partes.join(" AND "), rows: String(POR_PAGINA), page: String(archive.pagina), output: "json"
    });
    ["identifier", "title", "year"].forEach((c) => p.append("fl[]", c));
    p.append("sort[]", $("ordem").value);

    $("msg-archive").textContent = "Buscando…";
    $("mais").hidden = true;
    try {
      const r = await fetch("https://archive.org/advancedsearch.php?" + p);
      if (!r.ok) throw new Error(r.status);
      const j = await r.json();
      const docs = (j.response && j.response.docs) || [];
      const itens = docs.map((d) => ({
        fonte: "archive", id: d.identifier,
        titulo: Array.isArray(d.title) ? d.title[0] : d.title, ano: d.year
      }));
      const grade = $("grade-archive");
      itens.forEach((v) => grade.appendChild(cartao(v)));
      const total = (j.response && j.response.numFound) || 0;
      $("msg-archive").textContent = total ? `${total.toLocaleString("pt-BR")} resultados` : "Nada encontrado.";
      $("mais").hidden = archive.pagina * POR_PAGINA >= total;
    } catch {
      $("msg-archive").textContent = "Não consegui falar com o Internet Archive. Tente de novo em instantes.";
    } finally { archive.carregando = false; }
  }
  $("form-archive").addEventListener("submit", (e) => { e.preventDefault(); buscarArchive(true); });
  $("colecao").addEventListener("change", () => buscarArchive(true));
  $("ordem").addEventListener("change", () => buscarArchive(true));
  $("mais").addEventListener("click", () => { archive.pagina++; buscarArchive(false); });

  // ---------- minha lista ----------
  async function descobrirTitulo(v) {
    try {
      if (v.fonte === "archive") {
        const r = await fetch(`https://archive.org/metadata/${encodeURIComponent(v.id)}/metadata/title`);
        const j = await r.json();
        const t = Array.isArray(j.result) ? j.result[0] : j.result;
        if (t) return t;
      } else {
        const r = await fetch("https://www.youtube.com/oembed?format=json&url=" +
          encodeURIComponent("https://www.youtube.com/watch?v=" + v.id));
        const j = await r.json();
        if (j.title) return j.title;
      }
    } catch {}
    return "";
  }

  $("form-add").addEventListener("submit", async (e) => {
    e.preventDefault();
    const v = lerLink($("url").value);
    const msg = $("msg-add");
    if (!v) { msg.textContent = "Link não reconhecido. Use YouTube ou archive.org/details/…"; return; }
    if (minhaLista.some((x) => chave(x) === chave(v))) { msg.textContent = "Esse vídeo já está na lista."; return; }
    msg.textContent = "Adicionando…";
    v.titulo = $("titulo").value.trim() || (await descobrirTitulo(v)) ||
      (v.fonte === "youtube" ? "Vídeo do YouTube" : v.id);
    minhaLista.unshift(v);
    salvarMinha();
    $("form-add").reset();
    msg.textContent = "Adicionado!";
    renderMinha();
  });

  function renderMinha() {
    desenhar($("grade-minha"), minhaLista, { remover: true });
    $("vazio-minha").textContent = minhaLista.length ? "" : "Sua lista está vazia.";
  }

  carregarCatalogo();
  renderMinha();
})();
